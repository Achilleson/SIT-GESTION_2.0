# SIT-Gestion — Fabriquer l'installateur Windows (.exe), gratuit

1. Compte gratuit sur https://github.com, puis « + » > « New repository », nom : `sit-gestion-windows`.
2. « uploading an existing file » : glissez TOUT le contenu de ce dossier (y compris le dossier caché `.github`), puis « Commit changes ».
3. Onglet « Actions » > « Construire l'installateur Windows SIT-Gestion » > « Run workflow ». Attendez 4 à 8 minutes.
4. Ouvrez l'exécution terminée, section « Artifacts » : téléchargez « SIT-Gestion-Windows » (zip contenant SIT-Gestion-Setup-1.0.0.exe).

## Installer sans internet
- Copiez le .exe sur une clé USB, puis lancez-le sur chaque ordinateur Windows 10/11 (64 bits).
- Windows peut afficher « Windows a protégé votre ordinateur » (installateur non signé) : cliquez « Informations complémentaires » puis « Exécuter quand même ».
- Raccourcis créés sur le Bureau et dans le menu Démarrer. Fonctionne 100 % hors connexion ; les données restent sur l'ordinateur (pensez à exporter une sauvegarde depuis Paramètres).
